#!/bin/bash

sudo python3 ./wrr_test_proxy-5gnr-wifi6-lifi.py 1 1 1
sleep 30
sudo python3 ./wrr_test_proxy-5gnr-wifi6-lifi.py 5 25 1
sleep 30
sudo python3 ./wrr_test_proxy-5gnr-wifi6-lifi.py 15 50 1
sleep 30
sudo python3 ./wrr_test_proxy-5gnr-wifi6-lifi.py 30 100 1
sleep 30
sudo python3 ./wrr_test_proxy-5gnr-wifi6-lifi.py 15 50 1
sleep 30
sudo python3 ./wrr_test_proxy-5gnr-wifi6-lifi.py 5 25 1
sleep 30
sudo python3 ./wrr_test_proxy-5gnr-wifi6-lifi.py 1 1 1
sleep 30

sudo kill -9 `pgrep iperf3`
