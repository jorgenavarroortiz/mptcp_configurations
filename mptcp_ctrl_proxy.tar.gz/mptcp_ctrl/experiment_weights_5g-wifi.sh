#!/bin/bash

sudo python3 ./wrr_test_proxy-5gnr-wifi6-lifi.py 1 1 1
sleep 10
sudo python3 ./wrr_test_proxy-5gnr-wifi6-lifi.py 1 2 1
sleep 10
sudo python3 ./wrr_test_proxy-5gnr-wifi6-lifi.py 1 3 1
sleep 10
sudo python3 ./wrr_test_proxy-5gnr-wifi6-lifi.py 1 4 1
sleep 10
sudo python3 ./wrr_test_proxy-5gnr-wifi6-lifi.py 1 5 1
sleep 10
sudo python3 ./wrr_test_proxy-5gnr-wifi6-lifi.py 1 1 1
sleep 10
sudo python3 ./wrr_test_proxy-5gnr-wifi6-lifi.py 1 2 1
sleep 10
sudo python3 ./wrr_test_proxy-5gnr-wifi6-lifi.py 1 3 1
sleep 10
sudo python3 ./wrr_test_proxy-5gnr-wifi6-lifi.py 1 4 1
sleep 10
sudo python3 ./wrr_test_proxy-5gnr-wifi6-lifi.py 1 5 1
sleep 10

sudo kill -9 `pgrep iperf3`
