#!/bin/bash

DEBUG=0
CPE_QUECTEL="/home/jorge/quectel-linux/connect_quectel_amarisoft.sh"
CPE_STATS="/home/jorge/vagrant/stats/5g-clarity_testbed_v0_stats/start_stats.sh"
CHECKQUECTELCARD="/home/jorge/quectel-linux/check_quectel_card.sh"
CHECKCPECONNECTIVITY="/home/jorge/quectel-linux/check_5G_connectivity.sh"

REDIRECT=""
REDIRECT2=""
if [[ $DEBUG == 0 ]]; then
  REDIRECT=" 2> /dev/null"
  REDIRECT2=" > /dev/null"
fi

# Routing stuff
eval "sudo route del default" $REDIRECT                               # Remove default route (used for the management network interface)
#sudo route add -net 172.17.0.0/16 gw 192.168.100.100          # Access to eduroam, so "external" users may see the Grafana dashboard (using Wi-Fi USB dongles for management)
eval "sudo route add -net 172.17.0.0/16 gw 192.168.123.1" $REDIRECT   # Access to eduroam, so "external" users may see the Grafana dashboard (using Ethernet for management)
eval "sudo route add -net 172.17.0.0/16 gw 192.168.123.1" $REDIRECT
eval "sudo route add -net 79.144.0.0/16 gw 192.168.123.1" $REDIRECT   # Access to home network


eval "screen -XS quectel quit" $REDIRECT2
eval "screen -XS stats quit" $REDIRECT2

# Quectel card
   # Reset Quectel card
#if [ "$#" -eq 1 ]; then
   echo "[INFO] CPE: resetting Quectel card"
   eval "sudo /home/jorge/quectel-linux/reset_quectel.sh" $REDIRECT
#fi

   # Wait for the Quectel card to appear after reset
echo "[INFO] CPE: waiting for the Quectel card to appear after reset"
eval "$CHECKQUECTELCARD" $REDIRECT

   # Attach Quectel card to the 5G network
echo "[INFO] CPE: attaching card to the 5G network"
eval "screen -d -m -S quectel" $REDIRECT
eval "screen -S quectel -X exec bash $CPE_QUECTEL" $REDIRECT

   # Wait for the card to connect
echo "[INFO] CPE: waiting for connectivity"
eval "$CHECKCPECONNECTIVITY" $REDIRECT

CPE_INTERFACE=`eval "ip a | grep wwp | cut -d\" \" -f2 | cut -d\":\" -f1"`
CPE_IPADDRESS=`eval "ip a | grep wwp | grep inet | cut -d\" \" -f 6"`
echo "[INFO] CPE interface $CPE_INTERFACE with IP address $CPE_IPADDRESS"
