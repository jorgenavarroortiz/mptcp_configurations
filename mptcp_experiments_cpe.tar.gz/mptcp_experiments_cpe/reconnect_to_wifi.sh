sudo service wpa_supplicant restart
