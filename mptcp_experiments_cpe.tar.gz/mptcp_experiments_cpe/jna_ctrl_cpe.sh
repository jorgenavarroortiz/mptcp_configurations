#!/bin/bash

DEBUG=1

WEIGHTWIFI=$1
WEIGHT5G=$2

REDIRECT=""
REDIRECT2=""
if [[ $DEBUG == 0 ]]; then
  REDIRECT=" 2> /dev/null"
  REDIRECT2=" > /dev/null"
fi

# Run MPTCP on the CPE
echo "[INFO] executing MPTCP"
cd ~/free5gc/mptcp_test/
./set_MPTCP_parameters.sh -p fullmesh -s roundrobin -C N -c olia -f if_names.txt.nuc02.1WIFI-5GNR $REDIRECT

# Change WRR weights
cd ~/mptcp_ctrl
sudo python3 ./wrr_test_cpe-1wifi-5gnr.py $WEIGHTWIFI $WEIGHT5G
