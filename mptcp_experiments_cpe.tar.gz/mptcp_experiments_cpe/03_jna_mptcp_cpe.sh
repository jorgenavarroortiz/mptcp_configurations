#!/bin/bash

DEBUG=1

REDIRECT=""
REDIRECT2=""
if [[ $DEBUG == 0 ]]; then
  REDIRECT=" 2> /dev/null"
  REDIRECT2=" > /dev/null"
fi

# Run MPTCP on the CPE
echo "[INFO] executing MPTCP"
cd ~/free5gc/mptcp_test/
./set_MPTCP_parameters.sh -p fullmesh -s roundrobin -C N -c olia -f if_names.txt.nuc02.1WIFI-5GNR $REDIRECT
#./set_MPTCP_parameters.sh -p fullmesh -s roundrobin -C Y -c olia -f if_names.txt.nuc02.1WIFI-5GNR $REDIRECT
