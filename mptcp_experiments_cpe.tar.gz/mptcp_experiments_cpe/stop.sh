sudo kill -9 `pgrep python3`; ./jna_ctrl_cpe.sh 4 1
