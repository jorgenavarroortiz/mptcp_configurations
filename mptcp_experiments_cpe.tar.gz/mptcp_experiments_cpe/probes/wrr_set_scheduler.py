#!/usr/bin/env python3
import mptcp_wrr_controller as wrr 
import sys

def main():
    current=wrr.get_mptcp_current_scheduler()

    if len(sys.argv)>1:
        # We can set the scheduler to use for the next MPTCP sockets.
        # Possible values: "default", "redundant", "roundrobin"
        # Warning! We must have root provileges to use this command (under the hood, this function uses "sysctl -w")
        wrr.set_mptcp_scheduler(sys.argv[1])
        print("Switching scheduler for next MPTCP sockets from: "+current+" to "+wrr.get_mptcp_current_scheduler())
    else:
        print("Usage: "+sys.argv[0]+" [default|redundant|roundrobin]")

if __name__ == '__main__':
    main()