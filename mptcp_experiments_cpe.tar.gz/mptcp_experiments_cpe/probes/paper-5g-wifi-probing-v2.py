#!/usr/bin/env python3
import mptcp_wrr_controller as wrr 
import sys
import os
import random
import math
import subprocess
import json
import time

# Change meeeee!!!!!!!!!!!!!!
# inter=["enp0s8","enp0s17","enp0s10"]
interfaces=["wlo1","wwp0s20f0u2i4"]
ips=["172.16.32.2", "192.168.3.2"]
TARGET_IP="10.1.1.4"
interprobing_time=5
probing_time=5
merge_time=0

def read_info_json():
    process = subprocess.Popen(["ip", "-j", "-s","link","show"], stdout=subprocess.PIPE)
    jj=process.communicate()[0]
    dictionary = json.loads(jj)

    stats={}
    for i in dictionary:
        # print(i["ifname"]+" "+str(i["stats64"]["tx"]["bytes"]))
#        stats[i["ifname"]]=i["stats64"]["tx"]["bytes"]
        stats[i["ifname"]]=i["stats64"]["rx"]["bytes"]
    
    return stats

def read_info():
    stats={}
    # Using readlines()
    file = open('/proc/net/dev', 'r')
    lines = file.readlines()

    i=0
    for line in lines:
        if i>=2:
            params=line.split()
            stats[params[0].strip()]=int(params[1])
        i=i+1

    file.close()
    return stats

def read_stats_json():
    start = time.time() * 1000
    stats_from=read_info_json()
    stats_from["timestamp"]=start

    return stats_from

# ms
def read_stats():
    start = time.time() * 1000
    stats_from=read_info()
    stats_from["timestamp"]=start

    return stats_from

# ms
def update_stats():
    stop= time.time() * 1000
    stats_to=read_info()
    stats_to["timestamp"]=stop

    return stats_to

def probe(remoteIp, protocol, probe_time, ran):

    current=(wrr.get_mptcp_current_scheduler()).strip()
    current_=(current.split(" = "))
    current=current_[1].strip()

#    wrr.set_mptcp_scheduler("redundant")
    os.system("sshpass -p 5GLaboratory ssh jorge@192.168.123.103 \"/home/jorge/mptcp/jna_mptcp_proxy_redundant.sh \"")

    stats_from=read_stats_json()

    os.system("iperf3 -c "+remoteIp+" -R -t "+str(probe_time + merge_time)+" -p 5202 -P 10 &")
    time.sleep(probe_time)

    stats_to=read_stats_json()

    elapsed=(stats_to["timestamp"]-stats_from["timestamp"])/1000.0
    print(elapsed)
    bw={}

    values=""
    for value in stats_to:
        bw[value]=round(8*(stats_to[value]-stats_from[value])/elapsed,0)
        print("estimation: \""+value+"\" "+str(bw[value]))
        
 
#    wrr.set_mptcp_scheduler(current)
    os.system("sshpass -p 5GLaboratory ssh jorge@192.168.123.103 \"/home/jorge/mptcp/01_jna_mptcp_proxy.sh \"")  

    # time.sleep(inter_time)
    return bw

def gcd(a,b):
    if a==0:
        return b
    return gcd(b%a,a)

def weight_gcd(bw_):
    bww=[]

    gcd_=bw_[0]
    for i in range(1,len(bw_)):
        gcd_=gcd(gcd_,bw_[i])

   # to review!!!!!!	
    if gcd_==0:
    	gcd_=1

    for i in range(len(bw_)):
        bww.append(bw_[i]/gcd_)

    return bww

def str_bw(bw_):
    bww=str(bw_[0])

    for i in range(1,len(bw_)):
        bww=bww+"-"+str(bw_[i])
    
    return bww


# mptcp@mptcp-vmwarevirtualplatform:~$ ifstat -b -T -w -n | tee /tmp/fich.txt
def main():
    bw=[0]*len(interfaces)
    
#    current=wrr.get_mptcp_current_scheduler()
#    wrr.set_mptcp_scheduler("roundrobin")
    os.system("sshpass -p 5GLaboratory ssh jorge@192.168.123.103 \"/home/jorge/mptcp/01_jna_mptcp_proxy.sh \"")  

    ran=random.randrange(20000)
    
    for i in range(100):      
            ran=random.randrange(20000)
    
            bw__ = probe(TARGET_IP, "tcp", probing_time, ran)
            #print(bw__)
      
            for j in range(len(interfaces)):    
#            	bw[j] = bw__[interfaces[j]]
            	bw[j] = int(bw__[interfaces[j]] / 5e7) # ROUNDED TO UNITS OF 5 Mbps

            	print("bw[" + str(j) + "]: " + str(bw[j]))
      
            w=weight_gcd(bw)
            alg="gcd"
            
            rules = [{"dst_ip":ips[0], "weight":int(w[0])},{"dst_ip":ips[1], "weight":int(w[1])}]
            print("Assigning "+str(rules))

#            # period: 1s, 50 times...
#            os.system("(ifstat -b -T -w -n 1 55 | tee ifstat-"+str_bw(bw)+"-"+str(ran)+"-"+alg+".txt) &")
#
#            ##wrr.set_local_interfaces_rules(rules)
#            wrr.set_local_interfaces_rules(rules)
#            
            os.system("sshpass -p 5GLaboratory ssh jorge@192.168.123.103 \"/home/jorge/mptcp/jna_ctrl_proxy_cpe.sh " + str(int(w[0])) + " " + str(int(w[1])) + "\"")
            #os.system("sshpass -p 5GLaboratory ssh jorge@192.168.123.103 \"/home/jorge/mptcp/jna_ctrl_proxy_cpe.sh 5 1\"")

            os.system("iperf3 -c " + TARGET_IP + " -R -P 10 -t " + str(interprobing_time + 2*merge_time) + " &")
            time.sleep(interprobing_time + merge_time)

if __name__ == '__main__':
    main()
