#!/usr/bin/env python3
import time
import mptcp_wrr_controller as wrr

#
# Example of dinamically assigning weights to flows
#

def main():
    # "rules" is a list of tuples which define the set of weights to assign.
    # Currently, weights can be only set from outside a namespace. These weights/rules apply to all network namespaces and MPTCP sockets.
    # When the sending turn of a subflow begins, the WRR scheduler first checks if all the non-null parameters specified in each tuple matches the subflow parameters.
    # The parameters that can be specified are: "src_ip", "dst_ip", "src_port", "dst_port", and the desired weight (number of segments to be sent for each round) for that subflow.
    # Any other packet which does not meet with the tuple definition is assigned a weight of 1.

    wrr.set_mptcp_scheduler("roundrobin")

    # wifi, 5G, lifi
    rules = [{"dst_ip":"172.16.253.22", "weight":2},{"dst_ip":"172.16.253.132", "weight":1},{"dst_ip":"172.16.253.32", "weight":10}]
    # We set the weights with the following function:
    wrr.set_local_interfaces_rules(rules)
            

if __name__ == '__main__':
    main()
