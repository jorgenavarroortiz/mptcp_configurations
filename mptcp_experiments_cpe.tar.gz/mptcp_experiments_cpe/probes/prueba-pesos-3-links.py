#!/usr/bin/env python3
import mptcp_wrr_controller as wrr 
import sys
import os


def gcd(a,b):
    if a==0:
        return b
    return gcd(b%a,a)

def main():

    #current=wrr.get_mptcp_current_scheduler()
    wrr.set_mptcp_scheduler("roundrobin")
    
    rules = [{"src_ip":"10.1.1.2", "weight":23},{"src_ip":"10.1.2.2", "weight":19},{"src_ip":"10.1.3.2", "weight":17}] # GCD Algorithm
    rules = [{"src_ip":"10.1.1.2", "weight":1},{"src_ip":"10.1.2.2", "weight":1},{"src_ip":"10.1.3.2", "weight":1}] # Ceil Algorithm _> 83000 (en lugar de 85000. Pero se debe a 0.964 overhead de ip, ether y tcp?)
    rules = [{"src_ip":"10.1.1.2", "weight":2},{"src_ip":"10.1.2.2", "weight":2},{"src_ip":"10.1.3.2", "weight":1}] # Floor Algorithm
    
    bw=[115000,95000,85000]
    inter=["enp0s8","enp0s17","enp0s10"]

    for i in range(0,len(inter)):
        os.system("tc qdisc add dev "+inter[i]+" root netem rate "+str(bw[i])+"kbit");

    wrr.set_local_interfaces_rules(rules)
    os.system("iperf -c 10.1.1.3 -t 60")


    #wrr.set_mptcp_scheduler(current)

    for interface in inter:
        os.system("tc qdisc del dev "+interface+" root");

if __name__ == '__main__':
    main()