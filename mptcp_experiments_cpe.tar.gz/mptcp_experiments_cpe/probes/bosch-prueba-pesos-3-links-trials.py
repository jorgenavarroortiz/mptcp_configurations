#!/usr/bin/env python3
import mptcp_wrr_controller as wrr 
import sys
import os
import random
import math

def gcd(a,b):
    if a==0:
        return b
    return gcd(b%a,a)

# Change meeeee!!!!!!!!!!!!!!
inter=["enp0s8","enp0s17","enp0s10"]
ips=["10.0.0.1","10.0.0.2","10.0.0.3"]
TARGET_IP="10.0.0.200"
#

# Estimated ips...
bws=[[115000,95000,85000],
    [8000,6000,5000]]



def weight_gcd(bw_):
    bww=[]

    gcd_=bw_[0]
    for i in range(1,len(bw_)):
        gcd_=gcd(gcd_,bw_[i])

    for i in range(len(bw_)):
        bww.append(bw_[i]/gcd_)

    return bww


def weight_floor(bw_):
    bww=[]

    floor_=1
    minbw = bw_[len(bw_)-1]
    
    for bw__ in bw_:
        bww.append(int(math.floor(bw__/minbw)))
    return bww

def weight_ceil(bw_):
    bww=[]

    floor_=1
    minbw = bw_[len(bw_)-1]
    
    for bw__ in bw_:
        bww.append(int(math.ceil(bw__/minbw)))
    return bww

def weight_round(bw_):
    bww=[]

    floor_=1
    minbw = bw_[len(bw_)-1]
    
    for bw__ in bw_:
        bww.append(int(round(bw__/minbw)))
    return bww

# def weight_floor(bw_):
#     bww=[]


#     gcd_=gcd(bw_)
#     for i in range(len(bw_)):
#         bww[i]=bw_[i]/gcd_

#     return bww

def str_bw(bw_):
    bww=str(bw_[0])

    for i in range(1,len(bw_)):
        bww=bww+"-"+str(bw_[i])
    
    return bww


# mptcp@mptcp-vmwarevirtualplatform:~$ ifstat -b -T -w -n | tee /tmp/fich.txt
def main():

    #current=wrr.get_mptcp_current_scheduler()
    wrr.set_mptcp_scheduler("roundrobin")

    ran=random.randrange(20000)
    
    for bw in bws:
        
      
            w=weight_gcd(bw)
            alg="gcd"
            
            rules = [{"src_ip":ips[0], "weight":int(w[0])},{"src_ip":ips[1], "weight":int(w[1])},{"src_ip":ips[2], "weight":int(w[2])}]
            print("Assigning "+str(rules))

            # period: 1s, 50 times...
            os.system("(ifstat -b -T -w -n 1 55 | tee ifstat-"+str_bw(bw)+"-"+str(ran)+"-"+alg+".txt) &")

            wrr.set_local_interfaces_rules(rules)
            os.system("iperf -c "+TARGET_IP+" -t 60")


if __name__ == '__main__':
    main()
