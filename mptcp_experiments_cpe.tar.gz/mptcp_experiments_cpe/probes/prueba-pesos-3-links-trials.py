#!/usr/bin/env python3
import mptcp_wrr_controller as wrr 
import sys
import os
import random
import math

def gcd(a,b):
    if a==0:
        return b
    return gcd(b%a,a)

bws=[[115000,95000,85000],
    [36500,29500,24500],
    [29500,23500,19500],
    [30500,24500,20500],
    [49500,39500,32500],
    [7000,5000,4000],
    [45500,36500,30500],
    [38500,30500,25500],
    [35500,28500,23500],
    [44500,35500,29500],
    [9000,6000,5000],
    [8000,4000,3000],
    [8000,6000,5000]]


inter=["enp0s8","enp0s17","enp0s10"]

def weight_gcd(bw_):
    bww=[]

    gcd_=bw_[0]
    for i in range(1,len(bw_)):
        gcd_=gcd(gcd_,bw_[i])

    for i in range(len(bw_)):
        bww.append(bw_[i]/gcd_)

    return bww


def weight_floor(bw_):
    bww=[]

    floor_=1
    minbw = bw_[len(bw_)-1]
    
    for bw__ in bw_:
        bww.append(int(math.floor(bw__/minbw)))
    return bww

def weight_ceil(bw_):
    bww=[]

    floor_=1
    minbw = bw_[len(bw_)-1]
    
    for bw__ in bw_:
        bww.append(int(math.ceil(bw__/minbw)))
    return bww

def weight_round(bw_):
    bww=[]

    floor_=1
    minbw = bw_[len(bw_)-1]
    
    for bw__ in bw_:
        bww.append(int(round(bw__/minbw)))
    return bww

# def weight_floor(bw_):
#     bww=[]


#     gcd_=gcd(bw_)
#     for i in range(len(bw_)):
#         bww[i]=bw_[i]/gcd_

#     return bww

def str_bw(bw_):
    bww=str(bw_[0])

    for i in range(1,len(bw_)):
        bww=bww+"-"+str(bw_[i])
    
    return bww


# mptcp@mptcp-vmwarevirtualplatform:~$ ifstat -b -T -w -n | tee /tmp/fich.txt
def main():

    #current=wrr.get_mptcp_current_scheduler()
    wrr.set_mptcp_scheduler("roundrobin")

    ran=random.randrange(20000)
    
    for bw in bws:
        
        print("Setting "+str(bw))
        for i in range(0,len(inter)):
            os.system("tc qdisc add dev "+inter[i]+" root netem rate "+str(bw[i])+"kbit");

        #rules = [{"src_ip":"10.1.1.2", "weight":23},{"src_ip":"10.1.2.2", "weight":19},{"src_ip":"10.1.3.2", "weight":17}] # GCD Algorithm
        #rules = [{"src_ip":"10.1.1.2", "weight":1},{"src_ip":"10.1.2.2", "weight":1},{"src_ip":"10.1.3.2", "weight":1}] # Ceil Algorithm _> 83000 (en lugar de 85000. Pero se debe a 0.964 overhead de ip, ether y tcp?)
        
        for i in range(4):

            if i==0:
                w=weight_gcd(bw)
                alg="gcd"
            elif i==1:
                w=weight_round(bw)
                alg="round"
            elif i==2:
                w=weight_ceil(bw)
                alg="ceil"
            elif i==3:
                w=weight_floor(bw)
                alg="floor"

            rules = [{"src_ip":"10.1.1.2", "weight":int(w[0])},{"src_ip":"10.1.2.2", "weight":int(w[1])},{"src_ip":"10.1.3.2", "weight":int(w[2])}] # Floor Algorithm
            print("Assigning "+str(rules))

            # period: 1s, 50 times...
            os.system("(ifstat -b -T -w -n 1 55 | tee ifstat-"+str_bw(bw)+"-"+str(ran)+"-"+alg+".txt) &")

            wrr.set_local_interfaces_rules(rules)
            os.system("iperf -c 10.1.1.3 -t 60")


            #wrr.set_mptcp_scheduler(current)

        for interface in inter:
            os.system("tc qdisc del dev "+interface+" root");

if __name__ == '__main__':
    main()