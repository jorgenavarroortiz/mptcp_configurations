import sys
import os

bw=[100,10,2]


def gcd(a,b):
    if a==0:
        return b
    return gcd(b%a,a)

g=weight_gcd(bw)
print(g)

for i in bw:
	print (i/g)

