#!/bin/bash

DEBUG=1
CPE_QUECTEL="/home/jorge/quectel-linux/connect_quectel_amarisoft.sh"
CPE_STATS="/home/jorge/vagrant/stats/5g-clarity_testbed_v0_stats/start_stats.sh"
CHECKQUECTELCARD="/home/jorge/quectel-linux/check_quectel_card.sh"
CHECKCPECONNECTIVITY="/home/jorge/quectel-linux/check_5G_connectivity.sh"

REDIRECT=""
REDIRECT2=""
if [[ $DEBUG == 0 ]]; then
  REDIRECT=" 2> /dev/null"
  REDIRECT2=" > /dev/null"
fi

eval "screen -XS stats1 quit" $REDIRECT2
eval "screen -XS stats2 quit" $REDIRECT2
eval "screen -XS stats3 quit" $REDIRECT2

# Stats
echo "[INFO] CPE: adding stats"
sudo systemctl restart grafana-server
eval "screen -d -m -S stats1"
screen -S stats1 -X exec /home/jorge/vagrant/stats/node_exporter-1.1.2.linux-amd64/node_exporter $REDIRECT
eval "screen -d -m -S stats2"
screen -S stats2 -X exec /home/jorge/vagrant/stats/prometheus-2.27.1.linux-amd64/prometheus --config.file=/home/jorge/vagrant/stats/prometheus-2.27.1.linux-amd64/prometheus.yml $REDIRECT
eval "screen -d -m -S stats3"
screen -S stats3 -X exec python3 /home/jorge/vagrant/stats/5g-clarity_testbed_v0_stats/ss_exporter.py $REDIRECT
