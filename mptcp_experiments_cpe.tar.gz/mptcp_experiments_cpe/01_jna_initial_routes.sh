#!/bin/bash

# Routing stuff
eval "sudo route del default" $REDIRECT                               # Remove default route (used for the management network interface)
#sudo route add -net 172.17.0.0/16 gw 192.168.100.100                 # Access to eduroam, so "external" users may see the Grafana dashboard (using Wi-Fi USB dongles for management)
eval "sudo route add -net 172.17.0.0/16 gw 192.168.123.1" $REDIRECT   # Access to eduroam, so "external" users may see the Grafana dashboard (using Ethernet for management)
eval "sudo route add -net 172.17.0.0/16 gw 192.168.123.1" $REDIRECT
eval "sudo route add -net 79.144.0.0/16 gw 192.168.123.1" $REDIRECT   # Access to home network
eval "sudo route add -net 81.38.0.0/16 gw 192.168.123.1" $REDIRECT    # Access to home network
